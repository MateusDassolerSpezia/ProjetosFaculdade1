public class Exe28Uni5 {
    public Exe28Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe28Uni5();
    }
}

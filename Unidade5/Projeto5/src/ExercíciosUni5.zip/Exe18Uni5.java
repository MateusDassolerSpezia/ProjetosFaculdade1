public class Exe18Uni5 {
    public Exe18Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe18Uni5();
    }
}

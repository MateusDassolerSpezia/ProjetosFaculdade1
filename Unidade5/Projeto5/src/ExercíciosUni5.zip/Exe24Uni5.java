public class Exe24Uni5 {
    public Exe24Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe24Uni5();
    }
}

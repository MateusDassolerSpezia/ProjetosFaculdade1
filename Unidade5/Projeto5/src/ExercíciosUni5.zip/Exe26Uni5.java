public class Exe26Uni5 {
    public Exe26Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe26Uni5();
    }
}

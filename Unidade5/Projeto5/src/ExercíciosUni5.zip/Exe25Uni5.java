public class Exe25Uni5 {
    public Exe25Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe25Uni5();
    }
}

public class Exe10Uni5 {
    public Exe10Uni5() {

        int valorVariavel = 20;
        int conta = 0;

        for (int contador = 0; contador < 10; contador++) {
            if (contador % 2 == 0) {
                conta = valorVariavel + 25;
                conta *= conta;
                System.out.println(conta);
                valorVariavel += 10;
            } else {
                conta = valorVariavel + 25;
                conta *= conta;
                valorVariavel += 40;
                System.out.println(conta);
            }
        }
    }
    public static void main(String[] args) {
        new Exe10Uni5();
    }
}

public class Exe32Uni5 {
    public Exe32Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe32Uni5();
    }
}

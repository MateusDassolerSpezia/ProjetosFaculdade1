public class Exe27Uni5 {
    public Exe27Uni5() {
        
    }
    public static void main(String[] args) {
        new Exe27Uni5();
    }
}

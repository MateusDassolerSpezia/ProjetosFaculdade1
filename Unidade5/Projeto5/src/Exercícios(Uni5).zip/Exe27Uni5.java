import java.util.Scanner;

public class Exe27Uni5 {
    public Exe27Uni5() {
        Scanner sc = new Scanner(System.in);
    


        sc.close();
    }
    public static void main(String[] args) {
        new Exe27Uni5();
    }
}
